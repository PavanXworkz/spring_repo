package com.xworkz.rtodepartment.service;

import com.xworkz.rtodepartment.dto.DLDTO;

public interface DlService {
	boolean validateAndSave(DLDTO dldto);
}
