package com.xworkz.rtodepartment.mail;

public interface MailService {
	public boolean sentMail(String email, String otp);
}
