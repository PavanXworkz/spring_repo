
function handleName()
{
	console.log("Function fname is working");
}